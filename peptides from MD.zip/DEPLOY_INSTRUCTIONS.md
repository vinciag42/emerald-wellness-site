# Emerald Wellness — Deployment Package
## Files to push to GitHub repo: vinciag42/emerald-wellness-site (master branch)

| File | Status | Action |
|------|--------|--------|
| peptides.html | ✅ NEW | Upload to root |
| coming-soon.html | ✅ UPDATED | Replace existing |
| signup.html | ✅ UPDATED | Replace existing |
| index.html | ✅ UPDATED | Replace existing |

## How to deploy (2 minutes):
1. Go to https://github.com/vinciag42/emerald-wellness-site
2. Click "Add file" → "Upload files"
3. Drag ALL 4 files at once
4. Commit message: "Add peptides page + update nav and signup"
5. Click "Commit changes" to master
6. Vercel auto-deploys in ~60 seconds
7. Verify at https://emerald-wellness-site.vercel.app/peptides.html

## Post-deploy checklist:
- [ ] Visit /peptides.html — confirm page loads
- [ ] Test tab filters and search bar
- [ ] Verify nav link "Protocols" points to /peptides.html
- [ ] Confirm Microsoft 365 email at portal.office.com
- [ ] Check Klaviyo flow is live after domain allowlist
